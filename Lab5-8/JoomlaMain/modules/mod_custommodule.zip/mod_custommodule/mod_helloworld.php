<?php
defined('_JEXEC') or die;

require_once __DIR__ . '/helper.php';

require JModuleHelper::getLayoutPath('mod_helloworld');


/*
Загрузку необходимых файлов, таких как helper.php.
Обработку входных данных формы, если они были отправлены.
Подготовку данных для отображения.
Загрузку шаблона отображения (default.php).
*/