<?php
define('amaz_store_TOP_HEADER_LAYOUT_1', AMAZ_STORE_THEME_URI. "customizer/images/top-header-1.png");
define('amaz_store_TOP_HEADER_LAYOUT_2', AMAZ_STORE_THEME_URI. "customizer/images/top-header-2.png");
define('amaz_store_TOP_HEADER_LAYOUT_3', AMAZ_STORE_THEME_URI. "customizer/images/top-header-3.png");
define('amaz_store_TOP_HEADER_LAYOUT_NONE', AMAZ_STORE_THEME_URI. "customizer/images/top-header-none.png");

define('amaz_store_MAIN_HEADER_LAYOUT_ONE', AMAZ_STORE_THEME_URI. "customizer/images/header-layout-1.png");
define('amaz_store_MAIN_HEADER_LAYOUT_TWO', AMAZ_STORE_THEME_URI. "customizer/images/header-layout-2.png");
define('amaz_store_MAIN_HEADER_LAYOUT_THREE', AMAZ_STORE_THEME_URI. "customizer/images/header-layout-3.png");
define('amaz_store_MAIN_HEADER_LAYOUT_FOUR', AMAZ_STORE_THEME_URI. "customizer/images/header-layout-4.png");

define('amaz_store_FOOTER_WIDGET_LAYOUT_1', AMAZ_STORE_THEME_URI. "customizer/images/widget-footer-1.png");
define('amaz_store_FOOTER_WIDGET_LAYOUT_2', AMAZ_STORE_THEME_URI. "customizer/images/widget-footer-2.png");
define('amaz_store_FOOTER_WIDGET_LAYOUT_3', AMAZ_STORE_THEME_URI. "customizer/images/widget-footer-3.png");
define('amaz_store_FOOTER_WIDGET_LAYOUT_4', AMAZ_STORE_THEME_URI. "customizer/images/widget-footer-4.png");
define('amaz_store_FOOTER_WIDGET_LAYOUT_5', AMAZ_STORE_THEME_URI. "customizer/images/widget-footer-5.png");
define('amaz_store_FOOTER_WIDGET_LAYOUT_6', AMAZ_STORE_THEME_URI. "customizer/images/widget-footer-6.png");
define('amaz_store_FOOTER_WIDGET_LAYOUT_7', AMAZ_STORE_THEME_URI. "customizer/images/widget-footer-7.png");
define('amaz_store_FOOTER_WIDGET_LAYOUT_8', AMAZ_STORE_THEME_URI. "customizer/images/widget-footer-8.png");
define('amaz_store_FOOTER_WIDGET_LAYOUT_NONE', AMAZ_STORE_THEME_URI. "customizer/images/widget-footer-none.png");
//SLIDER
define('amaz_store_SLIDER_LAYOUT_1', AMAZ_STORE_THEME_URI. "customizer/images/slider-layout-1.png");
define('amaz_store_SLIDER_LAYOUT_2', AMAZ_STORE_THEME_URI. "customizer/images/slider-layout-2.png");
define('amaz_store_SLIDER_LAYOUT_3', AMAZ_STORE_THEME_URI. "customizer/images/slider-layout-3.png");
define('amaz_store_SLIDER_LAYOUT_4', AMAZ_STORE_THEME_URI. "customizer/images/slider-layout-4.png");
define('SLIDER_LAYOUT_2', AMAZ_STORE_THEME_URI. 'customizer/images/slider-layout-2.png');
define('SLIDER_LAYOUT_4', AMAZ_STORE_THEME_URI. 'customizer/images/slider-layout-4.png');
//category slider
define('amaz_store_CAT_SLIDER_LAYOUT_1', AMAZ_STORE_THEME_URI. "customizer/images/category-slider-1.png");
define('amaz_store_CAT_SLIDER_LAYOUT_2', AMAZ_STORE_THEME_URI. "customizer/images/category-slider-2.png");
define('amaz_store_CAT_SLIDER_LAYOUT_3', AMAZ_STORE_THEME_URI. "customizer/images/category-slider-3.png");
//Banner Slider
define('amaz_store_BANNER_IMG_LAYOUT_1', AMAZ_STORE_THEME_URI. "customizer/images/banner-image-1.png");
define('amaz_store_BANNER_IMG_LAYOUT_2', AMAZ_STORE_THEME_URI. "customizer/images/banner-image-2.png");
define('amaz_store_BANNER_IMG_LAYOUT_3', AMAZ_STORE_THEME_URI. "customizer/images/banner-image-3.png");
define('amaz_store_BANNER_IMG_LAYOUT_4', AMAZ_STORE_THEME_URI. "customizer/images/banner-image-4.png");
define('amaz_store_BANNER_IMG_LAYOUT_5', AMAZ_STORE_THEME_URI. "customizer/images/banner-image-5.png");
