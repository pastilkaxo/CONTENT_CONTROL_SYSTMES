<?php
/**
 * Header Options for  Amaz Store Theme.
 *
 * @package      Amaz Store
 * @author       Amaz Store
 * @since        Amaz Store 1.0.0
 */
$wp_customize->get_control( 'header_image' )->section = 'amaz-store-abv-header-clr';
$wp_customize->get_control( 'header_image' )->priority = 1;
