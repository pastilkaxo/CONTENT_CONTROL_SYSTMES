  <div class="th-dashboard">
      <div class="content free-pro">
            <table class="table">
               <tbody class="table-body">
                  <tr class="table-head">
                     <th class="title" align="left"><?php _e('Features','amaz-store'); ?></th>
                     <th class="status" align="center"><?php _e('Amaz Store','amaz-store'); ?> </th>
                     <th class="status" align="center"><?php _e('Amaz Store Pro','amaz-store'); ?> </th>
                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Section Hide Option','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Footer Layout','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Full Color & Background Control','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Basic)','amaz-store'); ?> </span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Advanced)','amaz-store'); ?> </span></td>
                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Frontpage Header Slider','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Ribbon Section','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Image & Video)','amaz-store'); ?> </span>
                        </td>

                  </tr>




                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Tabbed Product Carousel Section','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product Carousel Section','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Woo Category Section ','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(One Layout)','amaz-store'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Three Layout)','amaz-store'); ?> </span></td>

                  </tr>




                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product List Carousel Section','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Banner Section  ','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Two Layouts)','amaz-store'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Six Layouts)','amaz-store'); ?> </span></td>

                  </tr>

                    <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Highlight Section  ','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Move to top','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Fully Responsive','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Social Icons','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Ajax Search','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Pre loader','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Blog page setting','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Pagination option ( Shop Page, Blog Page)','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Numbered)','amaz-store'); ?> </span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Numbered, Load More, Infinite Scroll)','amaz-store'); ?> </span>
                        </td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product Quick View','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>






                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product Image Hover Style','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Zoom )','amaz-store'); ?> </span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Zoom, Swap and Swap Slide)','amaz-store'); ?> </span>
                     </td>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Post Slide Widget','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                  </tr>




                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Support','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Basic)','amaz-store'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     <span class="info"><?php _e('(Priority)','amaz-store'); ?> </span></td>

                  </tr>








                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Section Ordering','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Four Custom Section','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Big Featured Product Section','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Brand Section','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Tabbed Product Image Carousel Section','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Tabbed Product list Carousel Section','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Single Product Slide Widget','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Tabbed Product Widget','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Testimonial Widget','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Vertical Tabbed Product Widget','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>

                  
                    <tr class="feature-row th-buy-pro">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Pro Theme','amaz-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status upsell"><?php _e('Access to all Pro features','amaz-store'); ?> </td>
                     <td class="status success"><a href="<?php echo esc_url('https://themehunk.com/product/amaz-store/');?>" target="_blank" rel="external noreferrer noopener" class="components-button is-primary"><?php _e('Get Amaz Store Pro Now','amaz-store'); ?></a></td>
                  </tr>



               </tbody>
            </table>
      </div>
   </div>
