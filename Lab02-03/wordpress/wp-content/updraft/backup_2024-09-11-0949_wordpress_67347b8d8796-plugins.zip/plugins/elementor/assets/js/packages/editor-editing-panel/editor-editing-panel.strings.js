/* translators: %s: Element type title. */
__( 'Edit %s', 'elementor' );
__( 'General', 'elementor' );
__( 'Style', 'elementor' );
__( 'Size', 'elementor' );
__( 'Width', 'elementor' );
__( 'Height', 'elementor' );
__( 'Min. Width', 'elementor' );
__( 'Min. Height', 'elementor' );
__( 'Max. Width', 'elementor' );
__( 'Max. Height', 'elementor' );