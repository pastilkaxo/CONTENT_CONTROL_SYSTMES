﻿=== Advanced Product Search For WooCommerce ===
Contributors: aThemeArt
Tags:  woocommerce search page, woocommerce search form, woocommerce search filter, woocommerce search products, woocommerce search content, woocommerce search autocomplete, woocommerce advanced search, woocommerce search category, woocommerce search product attributes, woocommerce search by tag, woocommerce search by brand, woocommerce predictive, woocommerce live search, woocommerce single product search, woocommerce site search, woocommerce search, ajax, search, woocommerce, products, themes, woocommerce search by sku, woocommerce search results, woocommerce search shortcode , e-commerce, shop, ajax search, instant search, premium, aThemeArt, autocomplete, autosuggest, better search, category search, custom search, highlight terms, Live Search, Predictive Search, product search, relevant search, search highlight, search product, suggest, typeahead, WooCommerce Plugin, woocommerce product search, woocommerce search, wordpress ecommerce
Requires at least: 5.0
Tested up to: 6.3.6
Stable tag: 1.0.9
Requires PHP: 7.2.0
Donate link: https://athemeart.net/downloads/advanced-product-search-for-woo/
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Popup Cart Lite for WooCommerce for WooCommerce plugin that displays popup cart for add to cart action.

== Description ==

[__Live Demo__](https://eds.edatastyle.com/demo/aspw/).

Advanced Product search for woocommerce – powerful instant search plugin for WooCommerce.You just got to install and simply begin typewriting and you'll instantly see the product list that you simply search.

It create a simple search box that shows you live search results, by suggesting you product from your WooCommerce shop that match your search out criteria.

No coding for knowledge needed for making any search kind for your product search.

Download, install and victimisation the plugin is simple and fun, you'll be able to produce, customise and build the attractive search forms for your product search and may place it on any of the page or in elementor ,visual composer, kingcomposer, widget .

Plugin have the unlimited color schemes of your selections to match your theme.


**Features provided with this plugin:**
* Products search – Search across all your WooCommerce products
* Widget and shortcodes to show your WooCommerce searchform in anywhere you want in your WooCommerce site..
* Search in – Search in product title, content, excerpt, categories, tags and sku. Or just in some of them
* Product image – Each search result contains product image
* Works for both simple and variable products.
* Filter by Ascending and Descending
* Enable or disable searches by product category and tag.
* you can preview of advanced searcher option as per your setting.
* you can apply custom CSS for advanced searcher option.



**Premium Features:**
* Widget, elementor, visual composer, [kingcomposer](https://kingcomposer.com/) and shortcodes to show your WooCommerce searchform in anywhere you want in your WooCommerce site..
* Advanced settings page with lot of options
* Unlimited color schemes
*  Visibility/stock status option – choose what catalog visibility and stock status must be for product to displayed in search results
* Add to cart button in search results
* Search in WooCommerce product excerpt
* Search in WooCommerce product content
* Search in WooCommerce product categories
* Search in WooCommerce product tags
* An awesome feature that your competitors may not have.


the plugins tested or theme compatibility with Hello Elementor, OceanWP, Hestia, [Storefront](https://wordpress.org/themes/storefront/), [Astra](https://wpastra.com/). Avada, BeTheme, The7, Flatsome, Enfold, [shopstore](https://wordpress.org/themes/shopstore/) | The Theme, [Shoper](https://wordpress.org/themes/shoper/) , [WoodMart](https://themeforest.net/item/woodmart-woocommerce-wordpress-theme/20264492) and may more .... 

== Installation ==

= Automatic installation =

Install Advanced Product Search For Woo just like any other WordPress plugin.  
[Installing Plugins] (https://codex.wordpress.org/Managing_Plugins)


== Frequently Asked Questions ==

= Will this plugin work with my theme? =
Yes, it will work with any theme, but may require some styling to make it match nicely.

== Screenshots ==

1. preview screen 0
2. Plugins Options 1 
3. Plugins Options 2
4. Plugins Options 3

== Upgrade Notice ==

= 1.1.4 =
* Tested up to: 6.3.6

= 1.1.4 =
* Tested up to: 6.2.2

= 1.1.3 =
* Tested up to: 6.1.1

= 1.1.2 =
* add strip_tags tag for content 

= 1.0.1 =
* pro link updated.

= 1.0.1 =
* Initial release.


== Changelog ==

= 1.1.2 =
* add strip_tags tag for content 

= 1.1.1 =
* pro link updated.

= 1.1.1 =
* Initial release.