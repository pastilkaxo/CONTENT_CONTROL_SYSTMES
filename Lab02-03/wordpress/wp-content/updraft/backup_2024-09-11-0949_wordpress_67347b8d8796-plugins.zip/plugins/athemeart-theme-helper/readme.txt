=== aThemeArt Theme Helper ===
Contributors: aThemeArt
Tags: aThemeArt Theme Helper, Demo Importer, Theme Options
Requires at least: 4.6
Tested up to: 6.0.2
Stable tag: 1.0.4
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Import aThemeArt official themes demo content, widgets and theme settings with just one click.

== Description ==

Import <a href="https://profiles.wordpress.org/athemeart/#content-themes" target="_blank" rel="nofollow">aThemeArt</a> official themes demo content, widgets and theme settings with just one click.

== Installation ==

= Automatic installation =

Install Unlimited Background Slider just like any other WordPress plugin.  
[Installing Plugins] (https://codex.wordpress.org/Managing_Plugins)


== Frequently Asked Questions ==

= Will this plugin work with my theme? =
Yes, it will work with aThemeArt theme.

== Screenshots ==


== Changelog ==

= 1.0.2 =
* Demo Content link fixed.

= 1.0 =
* Initial release.